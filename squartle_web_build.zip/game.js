// Squartle Web Build Placeholder
console.log("Squartle Online Loaded");
